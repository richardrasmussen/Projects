<?php
mysqli_report(MYSQLI_REPORT_OFF);
$user = 'dev';
$pass = 'Festus1349$$$$';
$db = 'HistoricalDataArchive';
$ip = 'richardprasmussen.com';
$db_handle = @mysqli_connect($ip, $user, $pass, $db);
if (!$db_handle) {
    $db_handle = null;
}